
=== DALEK ===
=== DALEK HEAVY ===
=== DALEK LIGHT ===


Keith Bates / K-Type © 2006, 2015 (version 2.0)
www.k-type.com    -    info@k-type.com

Dalek is a distressed, small caps typeface based on the lettering used in the Dalek Book of 1964 and in the Daleks strip in TV21 comic. The fonts have overtones of Greek, Phoenician and Runic alphabets.

The latest version has a full complement of Latin Extended-A characters and numerous subtle outline improvements. The original medium weight can be downloaded free for personal use, and the family now contains Heavy and Light weights which are available from:
https://www.k-type.com/fonts/dalek/

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------ 